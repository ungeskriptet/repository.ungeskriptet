import json
import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcaddon
import xbmcplugin
import main
import os

__addon__ = xbmcaddon.Addon('plugin.video.weebtv')
addon_handle = int(sys.argv[1])
args = urllib.parse.parse_qs(sys.argv[2][1:])
username = __addon__.getSetting('username')
password = __addon__.getSetting('password')
weebtv = main.weebtv(username, password)


def __init__():
    mode = args.get('mode', None)
    menu = {
        1: ['live', 'Live TV', 'livetv.png', True],
        2: ['settings', 'Settings', 'settings.png', False],
        }
    if mode is None:
        for k, menuitem in menu.items():
            adddir(menuitem[0], menuitem[1], menuitem[2], menuitem[3])
        xbmcplugin.endOfDirectory(addon_handle)

    elif mode[0] == "live":
        channelsarray = json.loads(weebtv.getchanneldict())
        for i in channelsarray:
            k = channelsarray[i]
            cid = k['cid']
            title = k['channel_title']
            icon = k['channel_logo_url']
            user = k['user_name']
            addchannels(mode[0], title, icon, user, cid)
        xbmcplugin.endOfDirectory(addon_handle)
        player()

    elif mode[0] == "settings":
        __addon__.openSettings()


def player():
    cid = args.get('channel', None)
    if cid:
        channel_info = weebtv.getstreamchannelinfo(cid[0], __addon__.getSettingBool('hd'))
        icon = channel_info['imgLink']
        title = channel_info['title']
        li = xbmcgui.ListItem(cid[0])
        li.setInfo('video', {'title': title, 'plot': 'Channel name: %s\nStatus: %s\nPremium: %s\nURL: %s\n' % (title, channel_info['status'], bool(channel_info['premium']), channel_info['url'],)})
        li.setArt({'icon': icon})
        xbmc.Player().play(channel_info['url'], li)


def addchannels(mode, label, icon, user, cid):
    url = '%s?mode=%s&channel=%s' % (sys.argv[0], mode, cid)
    title = '[B]%s[/B]      [COLOR gray][I]by [B]%s[/B][/I][/COLOR]' % (label, user)
    li = xbmcgui.ListItem(title)
    li.setArt({'icon': icon})
    xbmcplugin.addDirectoryItem(addon_handle, url, li)


def adddir(mode, label, icon, isfolder):
    icon = os.path.join(__addon__.getAddonInfo('path'), 'resources/icons/') + icon
    url = '%s?mode=%s' % (sys.argv[0], mode)
    li = xbmcgui.ListItem(label)
    li.setArt({'icon': icon})
    xbmcplugin.addDirectoryItem(addon_handle, url, li, isfolder)


__init__()
