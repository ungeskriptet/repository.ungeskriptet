import urllib.parse
import urllib.request
import xbmcaddon

channelUrl = 'https://weeb.tv/api/getChannelList&option=online-alphabetical'
playerUrl = 'https://weeb.tv/api/setplayer'


class weebtv:
    def __init__(self, username=None, password=None):
        self.username = username
        self.password = password

    def getchanneldict(self):
        if self.username and self.password:
            data = urllib.parse.urlencode({'username': self.username, 'userpassword': self.password}).encode('utf8')
            channellist = urllib.request.urlopen(channelUrl, data)
        else:
            channellist = urllib.request.urlopen(channelUrl)
        response = channellist.read()
        return response

    def getstreamchannelinfo(self, cid, hd):
        values = {'platform': 'XBMC', 'cid': cid}
        if self.username and self.password:
            values['username'] = self.username
            values['userpassword'] = self.password
        headers = {'User-Agent': 'XBMC'}
        data = urllib.parse.urlencode(values).encode('utf8')
        request = urllib.request.Request(playerUrl, data, headers)
        response = urllib.request.urlopen(request)
        reslink = response.read().decode('utf8')
        rawparams = urllib.parse.parse_qs(reslink)
        params = {
            'status': rawparams["0"][0],
            'premium': rawparams["5"][0],
            'rtmpLink': rawparams["10"][0],
            'playPath': rawparams["11"][0],
            'ticket': rawparams["73"][0],
            'title': rawparams["6"][0],
            'imgLink': rawparams["8"][0]
        }
        if hd:
            params['playPath'] += 'HI'
        else:
            params['playPath'] += 'LOW'

        url = params['rtmpLink'] + '/' + params['playPath'] + ' live=true pageUrl=token swfUrl=' + params['ticket']
        params['url'] = url
        return params
